package utils;

public class Constantes {
    public static final int TOTAL_CARTAS = 40;
    public static final int CARTAS_PALO = 10;
}
