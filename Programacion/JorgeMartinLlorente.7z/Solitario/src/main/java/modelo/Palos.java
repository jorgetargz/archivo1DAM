package modelo;

public enum Palos {

    BASTOS, COPAS, ESPADAS, OROS,

}
